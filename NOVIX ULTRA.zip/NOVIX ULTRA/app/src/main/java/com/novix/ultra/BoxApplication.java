package com.novix.ultra;

import android.app.Application;

public class BoxApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // Initialization code yahan aayega
    }
}