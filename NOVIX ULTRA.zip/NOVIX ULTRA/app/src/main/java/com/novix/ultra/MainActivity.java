package com.novix.ultra;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {
    private Button btnLaunch, btnExit;
    private TextView tvTimer;
    
    // Game ka package name (Global ke liye com.tencent.ig)
    private String selectedPackage = "com.tencent.ig"; 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLaunch = findViewById(R.id.btnLaunch);
        btnExit = findViewById(R.id.btnExit);
        tvTimer = findViewById(R.id.tvTimer);

        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        }

        tvTimer.setText("Subscription: Active (Pro)");

        btnLaunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Injecting PAK & Launching...", Toast.LENGTH_SHORT).show();
                injectPakFile();
            }
        });

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, FloatMenu.class));
                finishAffinity();
            }
        });
    }

    private void injectPakFile() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // Assets se PAK file read karna
                    InputStream is = getAssets().open("gamepatch.pak");
                    byte[] buffer = new byte[is.available()];
                    is.read(buffer);
                    is.close();

                    // Game directory path
                    File paksDir = new File(Environment.getExternalStorageDirectory(), 
                            "Android/data/" + selectedPackage + "/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks");
                    
                    if (!paksDir.exists()) paksDir.mkdirs();

                    // PAK file write karna
                    File outFile = new File(paksDir, "gamepatch.pak");
                    FileOutputStream fos = new FileOutputStream(outFile);
                    fos.write(buffer);
                    fos.close();

                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "PAK Injected! Launching Game...", Toast.LENGTH_SHORT).show();
                            
                            Intent intent = getPackageManager().getLaunchIntentForPackage(selectedPackage);
                            if (intent != null) {
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                            startService(new Intent(MainActivity.this, FloatMenu.class));
                        }
                    });
                } catch (final Exception e) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Injection Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }
}