package com.novix.ultra;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class LoginActivity extends AppCompatActivity {

    private EditText etKey;
    private Button btnLogin;
    private ProgressBar progressBar;

    // YAHAN APNI NETLIFY YA VERCEL KI API LINK DAALEIN
    private static final String API_URL = "https://your-site.netlify.app/api/verify.php?key=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etKey = findViewById(R.id.etKey);
        btnLogin = findViewById(R.id.btnLogin);
        progressBar = findViewById(R.id.progressBar);

        SharedPreferences prefs = getSharedPreferences("auth", MODE_PRIVATE);
        if (prefs.getBoolean("isLoggedIn", false)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }

        btnLogin.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					String key = etKey.getText().toString().trim();
					if (key.isEmpty()) {
						Toast.makeText(LoginActivity.this, "Enter Key First!", Toast.LENGTH_SHORT).show();
						return;
					}
					verifyKey(key);
				}
			});
    }

    private void verifyKey(final String key) {
        progressBar.setVisibility(View.VISIBLE);
        btnLogin.setEnabled(false);

        new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						String urlStr = API_URL + URLEncoder.encode(key, "UTF-8");
						URL url = new URL(urlStr);
						HttpURLConnection conn = (HttpURLConnection) url.openConnection();
						conn.setRequestMethod("GET");

						BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
						StringBuilder response = new StringBuilder();
						String line;
						while ((line = reader.readLine()) != null) {
							response.append(line);
						}
						reader.close();

						JSONObject json = new JSONObject(response.toString());
						final String status = json.optString("status");

						new Handler(Looper.getMainLooper()).post(new Runnable() {
								@Override
								public void run() {
									progressBar.setVisibility(View.GONE);
									btnLogin.setEnabled(true);

									if (status.equals("success")) {
										getSharedPreferences("auth", MODE_PRIVATE).edit()
											.putBoolean("isLoggedIn", true)
											.putString("userKey", key)
											.apply();
										Toast.makeText(LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
										startActivity(new Intent(LoginActivity.this, MainActivity.class));
										finish();
									} else {
										Toast.makeText(LoginActivity.this, "Invalid Key", Toast.LENGTH_LONG).show();
									}
								}
							});

					} catch (final Exception e) {
						new Handler(Looper.getMainLooper()).post(new Runnable() {
								@Override
								public void run() {
									progressBar.setVisibility(View.GONE);
									btnLogin.setEnabled(true);
									Toast.makeText(LoginActivity.this, "Network Error", Toast.LENGTH_LONG).show();
								}
							});
					}
				}
			}).start();
    }
}
